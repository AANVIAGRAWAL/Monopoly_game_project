# MONOPLY
 This project is a C language implementation of the classic Monoply board game.
